<div id="loading-screen" class='flex space-x-2 justify-center items-center bg-white h-screen w-screen'>
    <div class='h-4 w-4 bg-[#209c55] rounded-full animate-bounce [animation-delay:-0.45s]'></div>
	<div class='h-4 w-4 bg-[#209c55] rounded-full animate-bounce [animation-delay:-0.3s]'></div>
	<div class='h-4 w-4 bg-[#209c55] rounded-full animate-bounce [animation-delay:-0.15s]'></div>
</div><?php /**PATH C:\laragon\www\mepro-visit\resources\views/components/loading.blade.php ENDPATH**/ ?>