<div class="h-fit gap-3 p-4 mt-10 overflow-auto bg-white rounded-xl shadow-sm transition-all duration-300">
    <!--begin::Table-->
    <table id="tableAkun" class="table-auto w-full text-sm" data-url="<?php echo e(route('akun.load')); ?>">
        <thead>
            <tr class="text-gray-500 text-center">
                <th>No</th>
                <th>Nama Karyawan</th>
                <th>Role</th>
                <th>Dibuat pada</th>
                <th>Dimodifikasi pada</th>
                <th>Status reset</th>
                <th>Aksi</th>
            </tr>
        </thead>
    </table>
    <!--end::Table-->
</div><?php /**PATH C:\laragon\www\mepro-visit\resources\views/components/accountTableList.blade.php ENDPATH**/ ?>